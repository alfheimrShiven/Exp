A Pen created at CodePen.io. You can find this one at https://codepen.io/defaultclass/pen/MqmOVB.

 clean card hover effect